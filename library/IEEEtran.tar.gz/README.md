# Manual #
- Items with [] mean the ones may exit. 
- Items with () mean the ones generated automatically and in which nothing should be manipulated manually. (*Except Documents directory*)
- the symbol following | is the type of the item. d for directory and f for file. 
## README.md    |f ##
This file. 
## Env.xml  |f ##
Environment for tex, i.e. the settings.

You can find the template in AutoLatex library and it is convenient to start a project from a template. 
## Structure.xml    |f ##
Structure configuration of you paper. Organize your sections by \<section\> label with the root label \<sections\>. 

Figures, tables and algorithms are inserted into the section with the following format: 

```xml
<figure name="fig: " id=${figureName} size="3.5" column="double">
<!-- column attribute notices this figure should be double column.
 If this figure is single column, delete it. -->
		${Caption}
</figure>
```

```xml
<table name="tab: " id=${tableName}></table>
<algorithm name="alg: " id=${algorithmName}></algorithm>
```

## Documents    |d ##
This directory is the structured tex files set, which is always corresponding to the configuration of *Structure.xml* after the operation of reflection. (see AutoLatex.README.md for details)
### (sectionName)   |d ###
### (......)    |d ###
## Target   |d ##
### Resources   |d ###
### ref.bib |f ###
### [templateName.cls]  |f ###
If the project is created from a template in AutoLatex library, you will see this item. 
### (projectName.xml)   |f ###
## .StructureBackup.xml    |f ##