#!/bin/bash
# This a shell script for color output with specific format
# author: kamisama
# date: 26-01-2020

string=$1
ColorPara=$2
FormatPara=$3

ColorLegitimateList="black red green brown blue purple cyan white"
FormatLegitimateList="bold subline flash"
ColorCodeList="black30 red31 green32 brown33 blue34 purple35 cyan36 white37"
BackCodeList="black40 red41 green42 brown43 blue44 purple45 cyan46 white47"
FormatCodeList="bold01 subline04 flash05"

if [[ "${string}" != "--help" ]]; then
	arrayColor=(${ColorPara//,/ })
	arrayFormat=(${FormatPara//,/ })
	lenColor=${#arrayColor[@]}
	lenFormat=${#arrayFormat[@]}

	case $lenColor in
	    0)
	        colorString="0"
	    ;;
	    1)
			varColor=${arrayColor[0]}

			# Correct parameter
	        if [[ ${ColorLegitimateList} == *${varColor}* ]]
			then
			    colorString=${ColorCodeList#*${varColor}*}
			    colorString=${colorString:0:2}
			# illegitimate parameter
			else
			    echo "Error: unknow type {$varColor}"
			    exit
			fi
	    ;;
	    2)
	        codeArr=(0 0)

	        # first parameter: font color
	        varColor=${arrayColor[0]}
	    	# Correct parameter
	    	if [[ ${ColorLegitimateList} == *${varColor}* ]]
	    	then
	    		tmpString=${ColorCodeList#*${varColor}*}
	    		codeArr[0]=${tmpString:0:2}
	    	# illegitimate parameter
	    	else
	    		echo "Error: unknow type {$varColor}"
		    	exit
	    	fi

	    	# second parameter: background color
	        varColor=${arrayColor[1]}
	    	# Correct parameter
	    	if [[ ${ColorLegitimateList} == *${varColor}* ]]
	    	then
	    		tmpString=${BackCodeList#*${varColor}*}
	    		codeArr[1]=${tmpString:0:2}
	    	# illegitimate parameter
	    	else
	    		echo "Error: unknow type {$varColor}"
		    	exit
	    	fi

	        colorString="${codeArr[0]};${codeArr[1]}"
	    ;;
	    *)
	        echo "Error: to many color parameters!(${len} parameters, with maximum of 2, however. )"
	        exit
	    ;;
	esac

	case $lenFormat in
		0)
			formatString="0"
		;;
		1)
			varFormat=${arrayFormat[0]}
			# Correct parameter
			if [[ $FormatLegitimateList == *$varFormat* ]]
			then
			    formatString=${FormatCodeList#*${varFormat}*}
			    formatString=${formatString:0:2}
			# illegitimate parameter
			else
			    echo "Error: unknow type {$varFormat}"
			    exit
			fi
		;;
		2)
			formatArr=(0 0)

			# first parameter
			varFormat=${arrayFormat[0]}
			# Correct parameter
			if [[ $FormatLegitimateList == *$varFormat* ]]
			then
			    tmpString=${FormatCodeList#*${varFormat}*}
			    formatArr[0]=${tmpString:0:2}
			# illegitimate parameter
			else
			    echo "Error: unknow type {$varFormat}"
			    exit
			fi

			# second parameter
			varFormat=${arrayFormat[1]}
			# Correct parameter
			if [[ $FormatLegitimateList == *$varFormat* ]]
			then
			    tmpString=${FormatCodeList#*${varFormat}*}
			    formatArr[1]=${tmpString:0:2}
			# illegitimate parameter
			else
			    echo "Error: unknow type {$varFormat}"
			    exit
			fi

			formatString="${formatArr[0]};${formatArr[1]}"
		;;
		3)
			formatArr=(0 0 0)

			# first parameter
			varFormat=${arrayFormat[0]}
			# Correct parameter
			if [[ $FormatLegitimateList == *$varFormat* ]]
			then
			    tmpString=${FormatCodeList#*${varFormat}*}
			    formatArr[0]=${tmpString:0:2}
			# illegitimate parameter
			else
			    echo "Error: unknow type {$varFormat}"
			    exit
			fi

			# second parameter
			varFormat=${arrayFormat[1]}
			# Correct parameter
			if [[ $FormatLegitimateList == *$varFormat* ]]
			then
			    tmpString=${FormatCodeList#*${varFormat}*}
			    formatArr[1]=${tmpString:0:2}
			# illegitimate parameter
			else
			    echo "Error: unknow type {$varFormat}"
			    exit
			fi

			# third parameter
			varFormat=${arrayFormat[2]}
			# Correct parameter
			if [[ $FormatLegitimateList == *$varFormat* ]]
			then
			    tmpString=${FormatCodeList#*${varFormat}*}
			    formatArr[2]=${tmpString:0:2}
			# illegitimate parameter
			else
			    echo "Error: unknow type {$varFormat}"
			    exit
			fi

			formatString="${formatArr[0]};${formatArr[1]};${formatArr[2]}"
		;;
		*)
			echo "Error: to many color parameters!(${len} parameters, with maximum of 3, however. )"
	        exit
		;;
	esac

	echo -e "\033[${colorString};${formatString}m$string\033[0m"
else
	echo "color: "${ColorLegitimateList}
	echo "format: "${FormatLegitimateList}
fi